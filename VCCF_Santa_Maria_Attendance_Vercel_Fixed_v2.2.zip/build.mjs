import { mkdirSync, copyFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const url = process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.VCCF_SUPABASE_URL;
const key = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || process.env.VCCF_SUPABASE_PUBLISHABLE_KEY;

if (!url || !key) {
  throw new Error('Missing NEXT_PUBLIC_SUPABASE_URL or NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY. Add them as Vercel Environment Variables.');
}

const out = 'public';
mkdirSync(out, { recursive: true });

for (const file of ['index.html', 'vccf-logo-black.png', 'vccf-logo-white.png']) {
  copyFileSync(file, join(out, file));
}

writeFileSync(join(out, 'vccf-config.js'), `// Generated at build time. Do not commit secrets.\nwindow.VCCF_SUPABASE_URL = ${JSON.stringify(url)};\nwindow.VCCF_SUPABASE_PUBLISHABLE_KEY = ${JSON.stringify(key)};\n`);

console.log('VCCF static site prepared in public/.');
