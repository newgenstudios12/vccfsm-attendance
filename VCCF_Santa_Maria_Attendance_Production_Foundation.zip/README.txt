VCCF Santa Maria Attendance App v1.7

Implemented:
- Admin-only Create Account option in Settings. Administrators can create Member, Area Leader, or Admin accounts, assign an area, and optionally link a member profile.
- Dashboard birthday feature appears automatically when a visible member has a birthday today. Area Leaders only see birthdays in their assigned area.
- Members > QR View by Area provides a QR-focused sheet for the selected/assigned area and includes a print-friendly action.
- Members visibility is role-aware: Area Leaders see their area; Member accounts see only their linked profile; Admins see all members.
- Featured Photos remain enlarged from v1.6.
- Added role-aware checks around account creation and QR access.

Production-readiness note:
This is a browser-deployable frontend package, but the current architecture still uses localStorage and client-side authentication for demo/offline operation. Before using real member data, connect the UI to a secure backend/database with HTTPS, server-side authorization, secure password hashing, managed sessions/cookies, backups, audit logs, CSRF protection, rate limiting, and appropriate privacy controls. Browser localStorage must not be treated as a production security boundary.
