# VCCF Santa Maria Attendance — Production Foundation

This package preserves the approved VCCF v1.7 UI while adding the production database/auth foundation.

## Permission model

- **Admin:** full access; can create/manage accounts and all data.
- **Area Leader:** can add/manage members and attendance only in their assigned area.
- **Member:** can check in and view the dashboard/gallery; member data is limited to their own profile.

## Important

The existing `index.html` is the approved prototype UI. It still contains localStorage/demo authentication and is **not yet the live production client**. Do not deploy it as the real system or use it with real member data.

The `supabase/migrations/20260818_000001_initial_vccf.sql` file is the production database foundation. It uses PostgreSQL RLS to enforce the role/area boundaries server-side.

## Next implementation steps

1. Create the Supabase schema using the migration (preferably via Supabase CLI/GitHub workflow).
2. Configure Supabase Auth.
3. Replace localStorage data access in `index.html` with authenticated Supabase queries.
4. Implement admin-only account provisioning server-side; never create passwords directly in browser code.
5. Move photos to Supabase Storage.
6. Replace QR payloads with non-sensitive random member codes resolved server-side.
7. Add server-side audit events for administrative mutations.
8. Run permission/security tests for all three roles.
9. Deploy through GitHub to Vercel.
10. Configure a custom domain, backups, monitoring, and production environment variables.

## Never commit

Do not commit `.env.local`, database passwords, Supabase secret/service-role keys, or other credentials.
